tar -a -c -f project.zip *
